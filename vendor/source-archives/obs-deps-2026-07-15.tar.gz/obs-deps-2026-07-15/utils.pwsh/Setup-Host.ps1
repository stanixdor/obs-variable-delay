function Setup-Host {
    if ( ! ( Test-Path function:Log-Output ) ) {
        . $PSScriptRoot/Logger.ps1
    }

    if ( ! ( Test-Path function:Check-Git ) ) {
        . $PSScriptRoot/Check-Git.ps1
    }

    Check-Git

    if ( ! ( Test-Path function:Invoke-External ) ) {
        . $PSScriptRoot/Invoke-External.ps1
    }

    try {
        $script:ProjectRoot = Invoke-External git rev-parse --show-toplevel 2>$null
    } catch {
        Log-Warning "Not running in a git repository, interpreting project root instead"
        $script:ProjectRoot = $($script:PSScriptRoot)
    }

    $script:WorkRoot = "${ProjectRoot}/windows_build_temp"

    if ( ! ( $script:SkipAll -or $script:SkipDeps ) ) {
        if ( ! ( Test-Path function:Install-BuildDependencies ) ) {
            . $PSScriptRoot/Install-BuildDependencies.ps1
        }

        Install-BuildDependencies -WingetFile ${script:PSScriptRoot}/.Wingetfile
    } else {
        Log-Debug "Skipping Install-BuildDependencies"
    }
}

function Cleanup {
    Log-Debug "Running Cleanup actions"
}

$script:HostArchitecture = ([System.Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture).ToString().ToLower()
